import { useState } from "react";

const Home = () => {

    const [test , setTest] = useState('TEST');

    function hideText(){
        let text = document.getElementById("test")
        setTest("test")
        if(text == "")
        {
            setTest("TEST");
        } else if(text == "TEST") {
            setTest("");
        }
    }

    const [blogs, setBlog] = useState([
        { title: 'My new website', body: 'lorem ipsum...', author: 'mario', id: 1 },
        { title: 'Welcome party!', body: 'lorem ipsum...', author: 'yoshi', id: 2 },
        { title: 'Web dev top tips', body: 'lorem ipsum...', author: 'mario', id: 3 }
    ])

    const [games, setGames] = useState([
        { title: 'RDR2', genre: 'Action', rDate: '2018', id: 1 },
        { title: 'GOW', genre: 'Adventure', rDate: '2018', id: 2 },
        { title: 'DS3', genre: 'Mystery', rDate: '2016', id: 3 }
    ])
    return (
        <div className="home">
            {blogs.map((blog) => (
                <div className="blog-preview" key={blog.id}>
                    <h2>{blog.title}</h2>
                    <p> Written by {blog.author } </p>
                    <p><strong> This blog says: </strong>  {blog.body} </p>
                </div>

            ))}
            <br></br>
            <h1 id="test"> {test} </h1>
                <button onClick={hideText} style={{
                    color: "white",
                    backgroundColor: "#355bf1df",
                    borderRadius: '8px',
                    fontSize: '25px',
                    borderColor: 'transparent',
                }}>
                    Hide text
                </button>


        </div>
    );
}

export default Home;